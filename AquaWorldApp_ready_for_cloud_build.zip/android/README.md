Создайте стандартную Android-часть командой `flutter create .` после распаковки, если она не создаётся автоматически. Затем выполните `flutter build appbundle --release`.
