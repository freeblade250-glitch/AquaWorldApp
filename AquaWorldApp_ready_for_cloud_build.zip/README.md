# AquaWorld App

Мобильное приложение AquaWorld на Flutter.

## Возможности
- Главная страница сервера
- Онлайн игроков через API
- Донат-магазин
- Правила
- Администрация
- Настройки сервера
- Защищённая админ-панель
- REST API для изменения магазина, правил и администрации
- Подготовлено для Android/RuStore

## Запуск
1. Установить Flutter.
2. Выполнить `flutter pub get`.
3. Указать адрес API в `lib/config.dart`.
4. Запустить `flutter run`.

## Сборка Android
`flutter build appbundle --release`

Для RuStore используется Android App Bundle/APK в соответствии с актуальными требованиями кабинета разработчика.

## Сборка без компьютера
В репозитории есть GitHub Actions workflow `.github/workflows/build-apk.yml`. Он автоматически создаёт Android-часть Flutter-проекта и собирает release APK в облаке.
